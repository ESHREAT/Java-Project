class Main{
	public static void main(String [] aa ){
		welcomePage l = new welcomePage();

	}
}
